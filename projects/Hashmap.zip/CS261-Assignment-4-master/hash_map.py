# hash_map.py
# ===================================================
# Implement a hash map with chaining
# ===================================================

class SLNode:
    def __init__(self, key, value):
        self.next = None
        self.key = key
        self.value = value

    def __str__(self):
        return '(' + str(self.key) + ', ' + str(self.value) + ')'


class LinkedList:
    def __init__(self):
        self.head = None
        self.size = 0

    def add_front(self, key, value):
        """Create a new node and inserts it at the front of the linked list
        Args:
            key: the key for the new node
            value: the value for the new node"""
        new_node = SLNode(key, value)
        new_node.next = self.head
        self.head = new_node
        self.size = self.size + 1

    def remove(self, key):
        """Removes node from linked list
        Args:
            key: key of the node to remove """
        if self.head is None:
            return False
        if self.head.key == key:
            self.head = self.head.next
            self.size = self.size - 1
            return True
        cur = self.head.next
        prev = self.head
        while cur is not None:
            if cur.key == key:
                prev.next = cur.next
                self.size = self.size - 1
                return True
            prev = cur
            cur = cur.next
        return False

    def contains(self, key):
        """Searches linked list for a node with a given key
        Args:
        	key: key of node
        Return:
        	node with matching key, otherwise None"""
        if self.head is not None:
            cur = self.head
            while cur is not None:
                if cur.key == key:
                    return cur
                cur = cur.next
        return None

    def __str__(self):
        out = '['
        if self.head != None:
            cur = self.head
            out = out + str(self.head)
            cur = cur.next
            while cur != None:
                out = out + ' -> ' + str(cur)
                cur = cur.next
        out = out + ']'
        return out

def hash_function_1(key):
    """Uses unicode values to generate an index"""
    hash = 0
    for i in key:
        hash = hash + ord(i)
    return hash


def hash_function_2(key):
    """Uses both the unicode values and adding index to generate an index"""
    hash = 0
    index = 0
    for i in key:
        hash = hash + (index + 1) * ord(i)
        index = index + 1
    return hash


class HashMap:
    """
    Creates a new hash map with the specified number of buckets.
    Args:
        capacity: the total number of buckets to be created in the hash table
        function: the hash function to use for hashing values
    """

    def __init__(self, capacity, function):
        self._buckets = []
        for i in range(capacity):
            self._buckets.append(LinkedList())
        self.capacity = capacity
        self._hash_function = function
        self.size = 0

    def clear(self):
        """
        Empties out the hash table deleting all links in the hash table.
        """
        for i in range(self.capacity):
            self._buckets[i] = LinkedList()

    def get(self, key):
        """
        Returns the value with the given key.
        Args:
            key: the value of the key to look for
        Return:
            The value associated to the key. None if the link isn't found.
        """

        # setting up variables to be used for navigation
        hash_val = self._hash_function(key)
        index = hash_val % self.capacity
        node = self._buckets[index].head

        if node is not None:
            # once we know it's not an empty bucket we traverse it to check keys
            while node.key != key and node.next is not None:
                node = node.next

            # if the key is present or we hit a .next = None the while loop will
            # terminate and this line will evaluate returning the value if the
            # key is present
            if node.key == key:
                return node.value

        # if the value is not present return None.
        else:
            return None

    def resize_table(self, capacity):
        """
        Resizes the hash table to have a number of buckets equal to the given
        capacity. All links need to be rehashed in this function after resizing
        Args:
            capacity: the new number of buckets.
        """

        # create a new list with the redefined capacity and current hash_func
        new_list = HashMap(capacity, self._hash_function)

        # iterate through the old hash map and rehash each node
        for i in range(self.capacity):

            # cur is used as a temporary value to make things easy
            cur = self._buckets[i].head

            if cur is not None:

                # add key/value pair to the new hash map
                new_list.put(cur.key, cur.value)

                # makes sure to traverse the linked list for each bucket
                while cur.next is not None:
                    cur = cur.next
                    new_list.put(cur.key, cur.value)

        # once we've rehashed all our values to the new map we change pointers
        self._buckets = new_list._buckets
        self.size = new_list.size
        self.capacity = new_list.capacity
        return True

    def put(self, key, value):
        """
        Updates the given key-value pair in the hash table. If a link with the
        given key already exists, this will just update the value and skip
        traversing. Otherwise, it will create a new link with the given key and
        value and add it to the table bucket's linked list.

        Args:
            key: the key to use to has the entry
            value: the value associated with the entry
        """

        # create our has index for the given value
        hash_val = self._hash_function(key)
        index = hash_val % self.capacity

        # check if the given index is occupied
        if self._buckets[index].head is not None:
            cur = self._buckets[index].head

            # make sure to traverse the linked list
            while cur.key is not key and cur.next is not None:
                cur = cur.next

            # if we find the key we update it's value
            if key == self._buckets[index].head.key:
                self._buckets[index].head.value = value

            # otherwise we simply add it to the front of the linked
            else:
                self._buckets[index].add_front(key, value)
                self.size = self.size + 1

        # if the spot is unoccupied we simple add it to the front.
        else:
            self._buckets[index] = LinkedList()
            self._buckets[index].add_front(key, value)
            self.size = self.size + 1
        return True

    def remove(self, key):
        """
        Removes and frees the link with the given key from the table. If no such
        link exists, this does nothing. Remember to search the entire linked
        list at the bucket.

        Args:
            key: they key to search for and remove along with its value
        """

        # setting up variables for navigation and evaluation
        hash_val = self._hash_function(key)
        index = hash_val % self.size
        prev = None
        node = self._buckets[index].head

        # if the bucket is occupied.
        if node is not None:

            # Traverse the linked list if necessary tracking previous node to
            # make pointer changes.
            while node.key is not key and node.next is not None:
                prev = node
                node = node.next

            # we not check to see if the current nodes key is the key we want.
            if node.key is key:

                # if the node is the head of the linked list
                if node is self._buckets[index].head:
                    self._buckets[index].head = node.next

                # if the node is not the head
                else:
                    prev.next = node.next

        # if something went wrong or the key is not in the list.
        else:
            return False

        # returns True if the value was removed.
        return True

    def contains_key(self, key):
        """
        Searches to see if a key exists within the hash table

        Returns:
            True if the key is found False otherwise

        """
        # copy pasta get and alter slightly...
        # setting up variables to be used for navigation
        hash_val = self._hash_function(key)
        index = hash_val % self.capacity
        node = self._buckets[index].head

        if node is not None:

            # once we know it's not an empty bucket we traverse it to check keys
            while node.key != key and node.next is not None:
                node = node.next

            # if the key is present or we hit a .next = None the while loop will
            # terminate and this line will evaluate returning the value if the
            # key is present
            if node.key == key:
                return True

        # if the value is not present return None.
        else:
            return False

    def empty_buckets(self):
        """
        Returns:
            The number of empty buckets in the table
        """
        # If I didn't have to work with skeleton code I would have made a data
        # member in the class to track this so I just paid the run time cost up
        # front and I could maintain the count allowing this to be a constant
        # time operation. Especially since I have to loop in the __init__.
        bucket_count = 0

        # simply iterate through the list check if the bucket contains a value
        for i in range(self.capacity):

            # if the bucket is empty we increment the counter.
            if self._buckets[i].head is None:
                bucket_count = bucket_count + 1

        # return the counts value
        return bucket_count

    def table_load(self):
        """
        Returns:
            the ratio of (number of links) / (number of buckets) in the table as
            a float.

        """
        # occupants tracks how many nodes are in the hash map
        occupants = 0

        # We iterate through the buckets using indexing generated by range with
        # the hash maps capacity.
        for i in range(self.capacity):

            # If the current bucket is not empty we count the node and set the
            # temporary variable cur to the current node,
            if self._buckets[i].head is not None:
                cur = self._buckets[i].head
                occupants = occupants + 1

                # we then traverse the LinkedList and count each node.
                while cur.next is not None:
                    cur = cur.next
                    occupants = occupants + 1

        # load is defined as the ratio of links to buckets so we return
        # occupants over capacity which contains the bucket count.
        return occupants/self.capacity

    def __str__(self):
        """
        Prints all the links in each of the buckets in the table.
        """

        out = ""
        index = 0
        for bucket in self._buckets:
            out = out + str(index) + ': ' + str(bucket) + '\n'
            index = index + 1
        return out
