"""if self._buckets[index] is not []:
    if key == self._buckets[index].head.key:
        self._buckets[index] = (key, value)
    else:
        self._buckets[index].add_front(key, value)
else:
    self._buckets[index] = (key, value)"""

"""student_map = HashMap(10, hash_function_1)
print(student_map)
student_map.put(first_node[0], first_node[1])
student_map.put(first_node[0], -5)
print(student_map.get(first_node[0]))
print(student_map)"""

    """
    keys = set()

    ht = HashMap(2500,hash_function_2)


    # This block of code will read a file one word as a time and
    # put the word in `w`. It should be left as starter code.
    with open(source) as f:
        for line in f:
            words = rgx.findall(line)
            for w in words:
                # FIXME: Complete this function

"""