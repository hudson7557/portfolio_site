// Comment out the server you are not using
//var serverUrl = 'http://localhost:3000';
var serverUrl = 'http://flip2.engr.oregonstate.edu:1344';