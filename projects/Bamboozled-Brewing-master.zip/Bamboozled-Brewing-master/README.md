# Bamboozled-Brewing
CS 290 website project for a fictitious seltzer brewing company. 

To open:
  Start with BBindex.html - it was renamed from index.html to prevent issues hosting this on another site.
